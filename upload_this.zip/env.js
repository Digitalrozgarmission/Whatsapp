const appVersion = "3.0.1";
const addON = [""];

module.exports = { appVersion, addON };
